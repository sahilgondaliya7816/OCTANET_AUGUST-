![Technical Documentation Page](images/TechnicalDocumentation.jpg)

# Technical Documentation Page
An HTML Documentation page developed for the freeCodecamp's Responsive Web Design Project "Build a Technical Documentation Page".<br/>
You can see the documentation page at [Codepen](https://codepen.io/sfoteini/full/OJMOQvV)
