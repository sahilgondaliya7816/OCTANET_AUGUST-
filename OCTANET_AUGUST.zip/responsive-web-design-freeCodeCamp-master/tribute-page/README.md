![Tribute Page Preview](images/TributePage_preview.jpg)

# Tribute Page
A tribute page dedicated to Vincent Van Gogh for my first challenge in FreeCodeCamp!<br/>
Responsive Web Design Certification - Project: Build a tribute page.<br/>
You can see the webpage at [CodePen](https://codepen.io/sfoteini/full/VweGZOK)<br/><br/>

Made with :heartpulse:
