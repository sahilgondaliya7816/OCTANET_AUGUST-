![Product Landing Page](images/landingPage.jpg)

# Product Landing Page
A product landing page for a medication reminder app. Created for the freeCodeCamp challenge "Build a Product Landing Page". <br/>
You can see the page at [CodePen](https://codepen.io/sfoteini/full/bGEPbNr)<br/>
** The information provided on the page are not real.<br/><br/>
Made with :heartpulse:
