![Personal Portfolio Webpage](images/personalPortfolio.jpg)

# Personal Portfolio
A personal portfolio webpage created for the freeCodeCamp challenge "Build a Personal Portfolio Webpage".<br/>
You can see the page at [CodePen](https://codepen.io/sfoteini/full/rNexONj)<br/><br/>
Made with :heartpulse:
